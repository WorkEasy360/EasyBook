"""Entitlement while a session lasts (completion-design section 4, contract 06).

Sign-in proved access once. A product session lives on, so the product keeps
asking ``workeasy360_entitlement_endpoint`` - on the platform's cadence, not
per request - and enforces the answer:

* an ``allow`` is trusted for ``min(revalidate_after, 900)`` seconds (at
  least 30);
* a ``deny`` is re-asked after 60 s when a person is waiting (a renewal takes
  effect quickly) and after 900 s for background work - decided by who is
  reading the answer, not by who asked for it;
* an **outage** (5xx, 429, timeout, network, unusable discovery, anything that
  is not an answer) is never a denial: the last answer stands and, with none,
  access continues; the next attempt, from any process, waits 60 s;
* a **refusal of this product's own client** (400/401/403, or an answer about
  another product) is not an outage and is client-wide: for 60 s every
  question fails closed with ``workeasy360_access_unverified`` without being
  asked. The refusal is also the question's last answer, so an outage right
  after it keeps refusing; it is asked again after 60 s, background work
  included. A 429 within 5 minutes of the last refusal counts as one: it
  extends the 60 s but does not move the moment the 5 minutes are measured
  from;
* a known denial never lapses into access: it is kept without expiry, and
  each process keeps its own copy, so a cache outage cannot hand access back;
* one request asks while the others use the last answer, but a first check
  is never waved through because another request happens to be asking.

Every question actually put to the platform is announced on
:data:`workeasy360_sso.signals.entitlement_checked`, for the product's logs.
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import OrderedDict
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from typing import Any

from django.core.cache import caches

from workeasy360_sso import client_auth, discovery, http, signals
from workeasy360_sso.conf import SSOConfig

logger = logging.getLogger("workeasy360_sso")

MIN_ALLOW_TTL = 30
MAX_ALLOW_TTL = 900
PERSON_DENY_RECHECK = 60
BACKGROUND_DENY_RECHECK = 900
OUTAGE_BACKOFF = 60
CLIENT_REFUSAL_HOLD = 60
REFUSAL_429_WINDOW = 300
LOCK_TIMEOUT = 15
ALLOW_RETENTION = 7 * 24 * 3600
LOCAL_MAX_ENTRIES = 20_000

ACCESS_ENDED = "workeasy360_access_ended"
READ_ONLY = "workeasy360_read_only"
ACCESS_UNVERIFIED = "workeasy360_access_unverified"

#: The reason recorded when the platform refused this product's own client.
CLIENT_REFUSED = "client_refused"

DENY_REASONS = frozenset(
    {"not_entitled", "expired", "suspended", "read_only", "no_seat", "membership_inactive"}
)


@dataclass(frozen=True)
class Answer:
    decision: str  # "allow" | "deny"
    reason: str
    write_allowed: bool
    checked_at: float
    #: When an ``allow`` must be asked again. A denial's re-check depends on
    #: who reads it (:func:`trusted_until`).
    trusted_until: float


@dataclass(frozen=True)
class AccessDecision:
    allowed: bool
    write_allowed: bool
    #: "" when allowed, else ACCESS_ENDED / ACCESS_UNVERIFIED.
    code: str
    #: The platform's reason (contract 06 section 4), e.g. "not_entitled";
    #: ``client_refused`` for a refusal of this product's client.
    reason: str
    #: True when no answer exists yet and the platform could not be asked.
    provisional: bool = False


def trusted_until(answer: Answer, *, background: bool) -> float:
    """Until when ``answer`` stands without asking again, for this reader."""
    if answer.decision == "allow":
        return answer.trusted_until
    if answer.reason == CLIENT_REFUSED:
        return answer.checked_at + CLIENT_REFUSAL_HOLD
    recheck = BACKGROUND_DENY_RECHECK if background else PERSON_DENY_RECHECK
    return answer.checked_at + recheck


# --- process-local state ----------------------------------------------------------


class _Local:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.answers: OrderedDict[str, Answer] = OrderedDict()
        self.backoff: dict[str, float] = {}
        #: The last real refusal (the 429 window is measured from it).
        self.client_refused_at = 0.0
        #: Until when every question fails closed.
        self.hold_until = 0.0


_local = _Local()


def _clock() -> float:
    """Wall-clock seconds. A seam for tests; nothing else should replace it."""
    return time.time()


def reset_state() -> None:
    global _local
    _local = _Local()


def _remember_local(key: str, answer: Answer) -> None:
    with _local.lock:
        _local.answers[key] = answer
        _local.answers.move_to_end(key)
        while len(_local.answers) > LOCAL_MAX_ENTRIES:
            # Evict the oldest *allow* first: a denial must not be the one forgotten.
            for candidate, value in _local.answers.items():
                if value.decision == "allow":
                    del _local.answers[candidate]
                    break
            else:
                _local.answers.popitem(last=False)


def _propagate(config: SSOConfig, exc: BaseException) -> None:
    """Re-raise exceptions the product says are never an outage (a task's time limit)."""
    if config.propagated_exception_types and isinstance(exc, config.propagated_exception_types):
        raise exc


# --- shared cache, every call failure-tolerant ------------------------------------


def _cache(config: SSOConfig):
    return caches[config.cache_alias]


def _cache_get(config: SSOConfig, key: str):
    try:
        return _cache(config).get(key)
    except Exception as exc:  # noqa: BLE001 - a cache outage must never become a denial or an error
        _propagate(config, exc)
        return None


def _cache_set(config: SSOConfig, key: str, value, timeout) -> None:
    try:
        _cache(config).set(key, value, timeout)
    except Exception as exc:  # noqa: BLE001 - a cache outage is never an error or a denial
        _propagate(config, exc)


def _cache_add(config: SSOConfig, key: str, value, timeout) -> bool:
    try:
        return _cache(config).add(key, value, timeout) is not False
    except Exception as exc:  # noqa: BLE001
        _propagate(config, exc)
        return True  # no shared lock available: ask, rather than wave through


def _cache_delete(config: SSOConfig, key: str) -> None:
    try:
        _cache(config).delete(key)
    except Exception as exc:  # noqa: BLE001 - a cache outage is never an error or a denial
        _propagate(config, exc)


def _key(config: SSOConfig, organization_id: uuid.UUID, subject: str | None) -> str:
    return f"w360sso:ent:{config.client_id}:{organization_id}:{subject or '-'}"


def _refused_key(config: SSOConfig) -> str:
    return f"w360sso:ent:{config.client_id}:client_refused_at"


def _hold_key(config: SSOConfig) -> str:
    return f"w360sso:ent:{config.client_id}:client_hold_until"


def _float(value: Any) -> float:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0.0


def _load_answer(config: SSOConfig, key: str) -> Answer | None:
    with _local.lock:
        local = _local.answers.get(key)
    shared_raw = _cache_get(config, key)
    shared = None
    if isinstance(shared_raw, dict):
        try:
            shared = Answer(**shared_raw)
        except TypeError:
            shared = None
    candidates = [a for a in (local, shared) if a is not None]
    if not candidates:
        return None
    # The newest real answer wins: a renewal (newer allow) supersedes an old
    # denial, but losing the cache can only ever leave the local denial.
    return max(candidates, key=lambda a: a.checked_at)


def _store_answer(config: SSOConfig, key: str, answer: Answer) -> None:
    _remember_local(key, answer)
    timeout = None if answer.decision == "deny" else ALLOW_RETENTION
    _cache_set(config, key, asdict(answer), timeout)


def last_answer(
    config: SSOConfig, *, organization_id: uuid.UUID, subject: str | None
) -> Answer | None:
    """The last answer known for this question, however old, or ``None``."""
    return _load_answer(config, _key(config, organization_id, subject))


def _last_refusal_at(config: SSOConfig) -> float:
    with _local.lock:
        local = _local.client_refused_at
    return max(local, _float(_cache_get(config, _refused_key(config))))


def _hold_until(config: SSOConfig) -> float:
    with _local.lock:
        local = _local.hold_until
    return max(local, _float(_cache_get(config, _hold_key(config))))


def _record_client_refusal(config: SSOConfig, now: float, *, anchor: bool) -> None:
    """Close every question for 60 s. ``anchor``: a real refusal, which also
    moves the moment the 429 window is measured from; a 429 read as a refusal
    only extends the hold."""
    with _local.lock:
        _local.hold_until = max(_local.hold_until, now + CLIENT_REFUSAL_HOLD)
        if anchor:
            _local.client_refused_at = now
    _cache_set(config, _hold_key(config), now + CLIENT_REFUSAL_HOLD, CLIENT_REFUSAL_HOLD + 5)
    if anchor:
        _cache_set(config, _refused_key(config), now, REFUSAL_429_WINDOW + CLIENT_REFUSAL_HOLD)


def _backing_off(config: SSOConfig, key: str, now: float) -> bool:
    with _local.lock:
        local = _local.backoff.get(key, 0.0)
    return now < max(local, _float(_cache_get(config, f"{key}:backoff")))


def _back_off(config: SSOConfig, key: str, now: float) -> None:
    with _local.lock:
        _local.backoff[key] = now + OUTAGE_BACKOFF
    _cache_set(config, f"{key}:backoff", now + OUTAGE_BACKOFF, OUTAGE_BACKOFF + 5)


def _clear_backoff(config: SSOConfig, key: str) -> None:
    with _local.lock:
        _local.backoff.pop(key, None)
    _cache_delete(config, f"{key}:backoff")


def _decide(answer: Answer) -> AccessDecision:
    if answer.decision == "allow":
        return AccessDecision(True, answer.write_allowed, "", answer.reason)
    if answer.reason == CLIENT_REFUSED:
        return UNVERIFIED
    return AccessDecision(False, False, ACCESS_ENDED, answer.reason)


UNVERIFIED = AccessDecision(False, False, ACCESS_UNVERIFIED, CLIENT_REFUSED)
PROVISIONAL = AccessDecision(True, True, "", "unverified_outage", provisional=True)


def _notify(config: SSOConfig, **kwargs: Any) -> None:
    results = signals.entitlement_checked.send_robust(sender=Answer, config=config, **kwargs)
    for _receiver, result in results:
        if isinstance(result, Exception):
            logger.warning(
                "workeasy360_sso.entitlement_receiver_failed",
                extra={"error": type(result).__name__},
            )


# --- the question -----------------------------------------------------------------


class _Outage(Exception):
    pass


class _Refused(Exception):
    def __init__(self, *, rate_limited: bool = False) -> None:
        super().__init__("refused")
        self.rate_limited = rate_limited


def check(
    config: SSOConfig,
    *,
    organization_id: uuid.UUID,
    subject: str | None,
    background: bool = False,
    fresh: bool = False,
    context: Mapping[str, Any] | None = None,
) -> AccessDecision:
    """May ``subject`` (or, without one, the organization) use this product now?

    ``fresh=True`` asks the platform now with ``write=true`` - use it before a
    privileged or irreversible operation (contract 06 section 9). It still
    honours the client-refusal hold and treats an outage like any other.
    ``context`` is passed unchanged to ``entitlement_checked`` receivers.
    """
    now = _clock()
    key = _key(config, organization_id, subject)

    if now < _hold_until(config):
        return UNVERIFIED

    answer = _load_answer(config, key)
    if answer is not None and now < trusted_until(answer, background=background) and not fresh:
        return _decide(answer)

    if not fresh and _backing_off(config, key, now):
        return _decide(answer) if answer is not None else PROVISIONAL

    lock_key = f"{key}:lock"
    if answer is not None and not fresh and not _cache_add(config, lock_key, 1, LOCK_TIMEOUT):
        return _decide(answer)  # somebody else is asking; the last answer stands

    notice = {
        "organization_id": organization_id,
        "subject": subject or "",
        "background": background,
        "previous": answer,
        "context": context,
    }
    try:
        try:
            fetched = _ask(
                config,
                organization_id=organization_id,
                subject=subject,
                background=background,
                write=fresh,
                now=now,
            )
        except (_Refused, _Outage):
            raise
        except Exception as exc:  # noqa: BLE001 - anything that is not an answer is an outage
            _propagate(config, exc)
            raise _Outage(type(exc).__name__) from exc
    except _Refused as refusal:
        _record_client_refusal(config, now, anchor=not refusal.rate_limited)
        _store_answer(config, key, Answer("deny", CLIENT_REFUSED, False, now, now + CLIENT_REFUSAL_HOLD))
        logger.error(
            "workeasy360_sso.entitlement_client_refused",
            extra={"organization_id": str(organization_id), "rate_limited": refusal.rate_limited},
        )
        _notify(config, outcome="refused", answer=None, detail="", rate_limited=refusal.rate_limited, **notice)
        return UNVERIFIED
    except _Outage as exc:
        _back_off(config, key, now)
        logger.warning(
            "workeasy360_sso.entitlement_unavailable",
            extra={"organization_id": str(organization_id), "detail": str(exc)},
        )
        _notify(config, outcome="outage", answer=None, detail=str(exc), rate_limited=False, **notice)
        return _decide(answer) if answer is not None else PROVISIONAL
    finally:
        if answer is not None and not fresh:
            _cache_delete(config, lock_key)

    _store_answer(config, key, fetched)
    _clear_backoff(config, key)
    _notify(config, outcome="answer", answer=fetched, detail="", rate_limited=False, **notice)
    return _decide(fetched)


def check_organization(
    config: SSOConfig, organization_id: uuid.UUID, *, context: Mapping[str, Any] | None = None
) -> AccessDecision:
    """For background work: organization-level, no person (completion-design 5)."""
    return check(
        config, organization_id=organization_id, subject=None, background=True, context=context
    )


def may_run_customer_job(config: SSOConfig, organization_id: uuid.UUID, *, job: str) -> bool:
    """Class A job rule: needs ``allow`` and ``write_allowed``; an outage runs.

    A denied job is skipped and logged, not retried in a loop; the caller
    leaves its schedule in place so the work resumes after a renewal.
    """
    decision = check_organization(config, organization_id)
    if decision.allowed and decision.write_allowed:
        return True
    logger.info(
        "workeasy360.background_skipped",
        extra={"organization_id": str(organization_id), "job": job, "reason": decision.reason},
    )
    return False


def _ask(
    config: SSOConfig,
    *,
    organization_id: uuid.UUID,
    subject: str | None,
    background: bool,
    write: bool,
    now: float,
) -> Answer:
    try:
        url = discovery.endpoint(config, "workeasy360_entitlement_endpoint")
        fields, headers = client_auth.authentication(config)
    except discovery.DiscoveryError as exc:
        raise _Outage(str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - an unreadable key is an outage, never a denial
        _propagate(config, exc)
        raise _Outage(type(exc).__name__) from exc

    data = {"organization_id": str(organization_id), "write": "true" if write else "false"}
    if subject:
        data["subject"] = subject
    data.update(fields)
    try:
        response = http.post_form(config, url, data, headers, timeout=config.entitlement_timeout)
    except http.ProviderUnavailable as exc:
        raise _Outage(str(exc)) from exc

    status = response.status_code
    if status == 429:
        # Measured when the 429 arrives: a refusal another question met while this one was in flight counts.
        refused_at = _last_refusal_at(config)
        if refused_at and _clock() - refused_at < REFUSAL_429_WINDOW:
            raise _Refused(rate_limited=True)
        raise _Outage("HTTP 429")
    if status >= 500:
        raise _Outage(f"HTTP {status}")
    if status in (400, 401, 403):
        raise _Refused()
    if status != 200:
        raise _Outage(f"HTTP {status}")

    try:
        payload = response.json()
    except ValueError as exc:
        raise _Outage("invalid JSON") from exc
    decision = payload.get("decision") if isinstance(payload, dict) else None
    if decision not in ("allow", "deny"):
        raise _Outage("no decision")
    echoed_product = payload.get("product_code")
    if echoed_product and echoed_product != config.product_code:
        # The answer is about another product: this client is misregistered.
        raise _Refused()
    echoed_org = payload.get("organization_id")
    if echoed_org and str(echoed_org) != str(organization_id):
        raise _Outage("answer for another organization")

    reason = str(payload.get("reason") or ("entitled" if decision == "allow" else "not_entitled"))[:64]
    if decision == "allow":
        try:
            revalidate = int(payload.get("revalidate_after") or MAX_ALLOW_TTL)
        except (TypeError, ValueError):
            revalidate = MAX_ALLOW_TTL
        ttl = max(MIN_ALLOW_TTL, min(revalidate, MAX_ALLOW_TTL))
        return Answer(
            decision="allow",
            reason=reason,
            write_allowed=payload.get("write_allowed") is True,
            checked_at=now,
            trusted_until=now + ttl,
        )
    recheck = BACKGROUND_DENY_RECHECK if background else PERSON_DENY_RECHECK
    if write and reason == "read_only":
        # A write refusal on a readable entitlement: reads stay allowed.
        return Answer("allow", reason, False, now, now + recheck)
    if reason == CLIENT_REFUSED:
        reason = "not_entitled"  # the platform's own word can never pose as a client refusal
    return Answer("deny", reason, False, now, now + PERSON_DENY_RECHECK)
