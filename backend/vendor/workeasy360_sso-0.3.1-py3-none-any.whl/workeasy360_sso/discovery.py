"""Provider metadata and signing keys, discovered from the issuer alone.

"Hard-code the issuer and nothing else" (integration guide section 3): every
endpoint comes from ``{issuer}/.well-known/openid-configuration``, whose
``issuer`` must equal the configured one exactly (OIDC Discovery 4.3).

The key set is cached and refreshed **once** on an unknown ``kid`` - which is
what makes platform key rotation invisible - and forced refreshes are spaced
at least ``MIN_FORCED_REFRESH_INTERVAL`` apart, so a stream of garbage tokens
with random ``kid`` values cannot turn this product into a request amplifier
against the platform.
"""

from __future__ import annotations

import threading
import time
from typing import Any

from workeasy360_sso import http
from workeasy360_sso.conf import SSOConfig, url_problem

MIN_FORCED_REFRESH_INTERVAL = 30.0
JWKS_TTL = 3600.0

REQUIRED_ENDPOINTS = ("authorization_endpoint", "token_endpoint", "jwks_uri")


class DiscoveryError(Exception):
    """The provider's metadata or key set is unusable. An outage, not a denial."""


class UnknownSigningKey(Exception):
    """No published key has the token's ``kid``, even after one refresh."""


class _Cache:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.metadata: dict[str, Any] | None = None
        self.metadata_at = 0.0
        self.jwks: dict[str, Any] | None = None
        self.jwks_at = 0.0
        self.last_forced_refresh = 0.0
        self.issuer = ""


_cache = _Cache()


def reset_cache() -> None:
    global _cache
    _cache = _Cache()


def metadata(config: SSOConfig, *, refresh: bool = False) -> dict[str, Any]:
    cache = _cache
    now = time.monotonic()
    with cache.lock:
        fresh = (
            cache.metadata is not None
            and cache.issuer == config.issuer
            and now - cache.metadata_at < config.discovery_ttl
        )
        if fresh and not refresh:
            return cache.metadata  # type: ignore[return-value]
    document = _fetch_metadata(config)
    with cache.lock:
        cache.metadata = document
        cache.metadata_at = time.monotonic()
        if cache.issuer != config.issuer:
            cache.jwks = None
        cache.issuer = config.issuer
    return document


def _fetch_metadata(config: SSOConfig) -> dict[str, Any]:
    url = f"{config.issuer}/.well-known/openid-configuration"
    try:
        document = http.get_json(config, url)
    except http.ProviderUnavailable as exc:
        raise DiscoveryError(f"discovery failed: {exc}") from exc
    if document.get("issuer") != config.issuer:
        # Describing somebody else's authorization server.
        raise DiscoveryError("the discovery document names a different issuer")
    for name in REQUIRED_ENDPOINTS:
        value = document.get(name)
        if not isinstance(value, str) or url_problem(
            value, allow_insecure_http=config.allow_insecure_http
        ):
            raise DiscoveryError(f"the discovery document has no usable {name}")
    methods = document.get("code_challenge_methods_supported")
    if methods is not None and "S256" not in methods:
        raise DiscoveryError("the provider does not support PKCE S256")
    return document


def endpoint(config: SSOConfig, name: str) -> str:
    value = metadata(config).get(name)
    if not isinstance(value, str) or not value:
        raise DiscoveryError(f"the provider does not advertise {name}")
    issue = url_problem(value, allow_insecure_http=config.allow_insecure_http)
    if issue:
        raise DiscoveryError(f"the advertised {name} {issue}")
    return value


def optional_endpoint(config: SSOConfig, name: str) -> str:
    try:
        return endpoint(config, name)
    except DiscoveryError:
        return ""


def _fetch_jwks(config: SSOConfig) -> dict[str, Any]:
    try:
        document = http.get_json(config, endpoint(config, "jwks_uri"))
    except http.ProviderUnavailable as exc:
        raise DiscoveryError(f"key set fetch failed: {exc}") from exc
    keys = document.get("keys")
    if not isinstance(keys, list):
        raise DiscoveryError("the key set has no keys")
    return document


def jwks(config: SSOConfig, *, refresh: bool = False) -> dict[str, Any]:
    cache = _cache
    with cache.lock:
        cached = cache.jwks
        fresh = cached is not None and time.monotonic() - cache.jwks_at < JWKS_TTL
        if cached is not None and fresh and not refresh:
            return cached
    document = _fetch_jwks(config)
    with cache.lock:
        cache.jwks = document
        cache.jwks_at = time.monotonic()
    return document


def signing_key(config: SSOConfig, kid: str) -> dict[str, Any]:
    """The published JWK with ``kid``; refreshes the cached set at most once."""
    if not kid or not isinstance(kid, str):
        raise UnknownSigningKey("the token names no key")
    found = _find(jwks(config), kid)
    if found is not None:
        return found
    cache = _cache
    with cache.lock:
        now = time.monotonic()
        allowed = now - cache.last_forced_refresh >= MIN_FORCED_REFRESH_INTERVAL
        if allowed:
            cache.last_forced_refresh = now
    if allowed:
        found = _find(jwks(config, refresh=True), kid)
        if found is not None:
            return found
    raise UnknownSigningKey("no published key has that kid")


def _find(document: dict[str, Any], kid: str) -> dict[str, Any] | None:
    for key in document.get("keys", []):
        if isinstance(key, dict) and key.get("kid") == kid and key.get("use", "sig") == "sig":
            return key
    return None


def supports_backchannel_logout(config: SSOConfig) -> bool:
    try:
        return bool(metadata(config).get("backchannel_logout_supported"))
    except DiscoveryError:
        return False
