"""HTTP endpoints of the connector. Mount them with ``include("workeasy360_sso.urls")``.

* ``start``      - begin a sign-in (also "confirm it's you" with ``reauth=1``)
* ``callback``   - the registered redirect URI
* ``logout``     - sign out of this product only (POST)
* ``logout_workeasy360`` - sign out of this product and WorkEasy360 (POST)
* ``backchannel_logout`` - OpenID Connect Back-Channel Logout 1.0 receiver
* ``status``     - non-secret configuration facts for readiness checks

A product may mount any of them at its own paths, or serve ``start`` and
``callback`` from its own views built on :mod:`workeasy360_sso.api`; see
:func:`workeasy360_sso.urls.namespaced`.
"""

from __future__ import annotations

import logging
from urllib.parse import urlencode

from django.contrib.auth import logout as django_logout
from django.db import IntegrityError, transaction
from django.http import (
    HttpRequest,
    HttpResponse,
    HttpResponseNotAllowed,
    HttpResponseRedirect,
    JsonResponse,
)
from django.shortcuts import render, resolve_url
from django.urls import NoReverseMatch, reverse
from django.views.decorators.csrf import csrf_exempt

from workeasy360_sso import __version__, api, discovery, sessions, signals, tokens
from workeasy360_sso.conf import get_config
from workeasy360_sso.errors import SignInRefused, message_for
from workeasy360_sso.models import ProductSession, ReceivedLogoutToken
from workeasy360_sso.organizations import SESSION_KEY, get_context
from workeasy360_sso.redirects import safe_next

logger = logging.getLogger("workeasy360_sso")

SIGNED_OUT_COOKIE = "w360sso_signed_out"
AUTO_START_COOKIE = "w360sso_auto"
AUTO_START_GUARD_SECONDS = 60


_no_store = api.no_store


def _reverse(name: str) -> str:
    """The path of one of the connector's routes, or "" where the product serves none."""
    try:
        return reverse(f"workeasy360_sso:{name}")
    except NoReverseMatch:
        return ""


def _default_destination() -> str:
    return resolve_url(get_config().login_redirect_url)


def start(request: HttpRequest) -> HttpResponse:
    if request.method not in ("GET", "HEAD"):
        return HttpResponseNotAllowed(["GET"])
    next_path = safe_next(request.GET.get("next"), default=_default_destination())
    organization = request.GET.get("organization")
    prompt = request.GET.get("prompt", "")
    reauth_subject = ""

    if request.GET.get("reauth") == "1":
        context = get_context(request)
        if context is None:
            return _error_response(request, SignInRefused("reauthentication_failed"))
        reauth_subject = context.subject
        organization = str(context.organization_id)
        prompt = "login"
    elif (
        request.user.is_authenticated
        and get_context(request) is not None
        and not organization
        and not prompt
    ):
        return _no_store(HttpResponseRedirect(next_path))

    automatic = request.GET.get("auto") == "1"
    try:
        response = api.begin_sign_in(
            request,
            organization=organization,
            next_path=next_path,
            prompt=prompt,
            reauth_subject=reauth_subject,
            automatic=automatic,
        )
    except SignInRefused as refusal:
        logger.warning("workeasy360_sso.start_failed", extra={"code": refusal.log_reason})
        return _error_response(request, refusal)

    if automatic:
        response.set_cookie(
            AUTO_START_COOKIE,
            "1",
            max_age=AUTO_START_GUARD_SECONDS,
            secure=request.is_secure(),
            httponly=True,
            samesite="Lax",
        )
    return _no_store(response)


def callback(request: HttpRequest) -> HttpResponse:
    if request.method != "GET":
        return HttpResponseNotAllowed(["GET"])
    try:
        result = api.complete_sign_in(request)
    except SignInRefused as refusal:
        logger.info("workeasy360_sso.sign_in_refused", extra={"code": refusal.log_reason})
        return _error_response(request, refusal)

    destination = safe_next(result.flow.next_path, default=_default_destination())
    response = HttpResponseRedirect(destination)
    response.delete_cookie(SIGNED_OUT_COOKIE)
    response.delete_cookie(AUTO_START_COOKIE)
    return _no_store(response)


def _error_response(request: HttpRequest, refusal: SignInRefused) -> HttpResponse:
    config = get_config()
    if config.error_redirect_url:
        target = resolve_url(config.error_redirect_url)
        separator = "&" if "?" in target else "?"
        response: HttpResponse = HttpResponseRedirect(
            f"{target}{separator}{urlencode({'sso_error': refusal.code})}"
        )
    else:
        status = 503 if refusal.code in ("unavailable", "rate_limited") else 403
        response = render(
            request,
            "workeasy360_sso/error.html",
            {
                "code": refusal.code,
                "message": message_for(refusal.code),
                "retry_url": _reverse("start") or resolve_url(config.login_url),
                "purchase_url": config.purchase_url if refusal.code == "not_entitled" else "",
            },
            status=status,
        )
    return _no_store(response)


def _sign_out_locally(request: HttpRequest, *, reason: str) -> None:
    data = request.session.get(SESSION_KEY) if hasattr(request, "session") else None
    if isinstance(data, dict):
        sessions.end_one(data.get("product_session_id"), reason=reason)
    django_logout(request)


def _signed_out_marker(response: HttpResponse, request: HttpRequest) -> None:
    # A browser-session cookie that suppresses automatic sign-in until the
    # person signs in again, so "Sign out" never ends in a silent sign-in.
    response.set_cookie(
        SIGNED_OUT_COOKIE, "1", secure=request.is_secure(), httponly=True, samesite="Lax"
    )


def logout(request: HttpRequest) -> HttpResponse:
    """Sign out of this product only. Other products and WorkEasy360 stay signed in."""
    if request.method != "POST":
        if request.method == "GET":
            return render(
                request,
                "workeasy360_sso/logout_confirm.html",
                {"everywhere": False, "config": get_config()},
            )
        return HttpResponseNotAllowed(["GET", "POST"])
    _sign_out_locally(request, reason=ProductSession.EndReason.SIGNED_OUT)
    response = HttpResponseRedirect(resolve_url(get_config().logout_redirect_url))
    _signed_out_marker(response, request)
    return _no_store(response)


def logout_workeasy360(request: HttpRequest) -> HttpResponse:
    """Sign out of this product, then of WorkEasy360 (RP-initiated logout).

    WorkEasy360 asks "Sign out of WorkEasy360 too?" (a GET cannot sign anyone
    out) and, once it supports back-channel logout, ends the other products'
    sessions of that sign-in as well.
    """
    config = get_config()
    if request.method != "POST":
        if request.method == "GET":
            return render(
                request, "workeasy360_sso/logout_confirm.html", {"everywhere": True, "config": config}
            )
        return HttpResponseNotAllowed(["GET", "POST"])
    _sign_out_locally(request, reason=ProductSession.EndReason.SIGNED_OUT_WORKEASY360)
    target = api.end_session_url(config) or resolve_url(config.logout_redirect_url)
    response = HttpResponseRedirect(target)
    _signed_out_marker(response, request)
    return _no_store(response)


@csrf_exempt
def backchannel_logout(request: HttpRequest) -> HttpResponse:
    """OpenID Connect Back-Channel Logout 1.0 section 2.5-2.8.

    Server to server, no cookies, no CSRF token (the provider's signature is
    the authentication). 200 once the named sessions are ended; 400 for a
    token that does not verify or was already accepted (the provider must not
    retry it); 503 when the key set cannot be read or ending the sessions
    failed (the provider should retry).

    Recording the ``jti``, ending the sessions and the
    :data:`~workeasy360_sso.signals.backchannel_logout` receivers share one
    database transaction: if any of it fails, none of it happened - the
    ``jti`` included - so the provider's retry is not refused as a replay.
    """
    config = get_config()
    if not config.backchannel_logout:
        return HttpResponse(status=404)
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    token = request.POST.get("logout_token", "")
    try:
        claims = tokens.verify_logout_token(config, token)
    except tokens.TokenRejected as exc:
        logger.warning("workeasy360_sso.logout_token_rejected", extra={"reason": exc.reason})
        return _no_store(JsonResponse({"error": "invalid_request"}, status=400))
    except discovery.DiscoveryError:
        logger.warning("workeasy360_sso.logout_jwks_unavailable")
        return _no_store(JsonResponse({"error": "temporarily_unavailable"}, status=503))

    subject, sid = str(claims.get("sub") or ""), str(claims.get("sid") or "")
    replayed = False
    try:
        with transaction.atomic():
            try:
                with transaction.atomic():
                    ReceivedLogoutToken.objects.create(
                        jti=str(claims["jti"])[:255], issuer=config.issuer
                    )
            except IntegrityError:
                replayed = True
            else:
                ended = sessions.end_for_logout_token(
                    issuer=config.issuer, subject=subject or None, sid=sid or None
                )
                signals.backchannel_logout.send(
                    sender=backchannel_logout,
                    request=request,
                    issuer=config.issuer,
                    subject=subject,
                    sid=sid,
                    claims=claims,
                    product_sessions=ended,
                )
    except Exception:  # noqa: BLE001 - whatever failed, the provider must deliver the token again
        logger.exception("workeasy360_sso.backchannel_logout_failed")
        return _no_store(JsonResponse({"error": "temporarily_unavailable"}, status=503))
    if replayed:
        logger.warning("workeasy360_sso.logout_token_replayed")
        return _no_store(JsonResponse({"error": "invalid_request"}, status=400))
    logger.info(
        "workeasy360_sso.backchannel_logout",
        extra={"subject": subject, "sessions_ended": len(ended)},
    )
    return _no_store(HttpResponse(status=200))


def status(request: HttpRequest) -> HttpResponse:
    """Facts a readiness check can compare with the registration. No secrets."""
    config = get_config()
    if not config.expose_status:
        return HttpResponse(status=404)
    backchannel = ""
    if config.backchannel_logout and _reverse("backchannel_logout"):
        backchannel = request.build_absolute_uri(_reverse("backchannel_logout"))
    return _no_store(
        JsonResponse(
            {
                "connector": "workeasy360-sso",
                "version": __version__,
                "configured": config.is_configured,
                "issuer": config.issuer,
                "client_id": config.client_id,
                "product_code": config.product_code,
                "redirect_uri": config.redirect_uri,
                "post_logout_redirect_uri": config.post_logout_redirect_uri,
                "backchannel_logout_uri": backchannel,
                "token_endpoint_auth_method": (
                    "private_key_jwt" if config.uses_private_key_jwt else "client_secret_basic"
                ),
                "sso_only": config.sso_only,
            }
        )
    )
