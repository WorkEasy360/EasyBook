"""Product sessions opened by WorkEasy360 sign-ins, and ending them.

Back-channel logout deletes the product's session **server-side** through
the configured session engine, so it needs a server-side engine (database,
cache or cached_db). The system checks refuse the signed-cookie engine when
back-channel logout is on: a cookie the server cannot revoke cannot be
signed out from anywhere else.

Every Django logout of a session the connector tracks also ends its
:class:`~workeasy360_sso.models.ProductSession` record (``user_logged_out``),
whichever view signed the person out.
"""

from __future__ import annotations

import logging
import uuid
from importlib import import_module
from typing import Any, Iterable

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from workeasy360_sso.models import EndedProviderSession, FederatedIdentity, ProductSession
from workeasy360_sso.organizations import SESSION_KEY

logger = logging.getLogger("workeasy360_sso")


def _session_store():
    return import_module(settings.SESSION_ENGINE).SessionStore


def delete_session(session_key: str) -> None:
    if session_key:
        _session_store()(session_key=session_key).delete()


def _end(rows: Iterable[ProductSession], *, reason: str) -> list[ProductSession]:
    ended: list[ProductSession] = []
    now = timezone.now()
    for row in rows:
        delete_session(row.session_key)
        if row.ended_at is None:
            row.ended_at = now
            row.end_reason = reason
            row.save(update_fields=["ended_at", "end_reason"])
            ended.append(row)
    return ended


def end_product_sessions(sessions: Iterable[ProductSession], *, reason: str) -> int:
    """End each session server-side and record why. Returns how many."""
    return len(_end(sessions, reason=reason))


@transaction.atomic
def end_for_logout_token(
    *, issuer: str, subject: str | None, sid: str | None
) -> list[ProductSession]:
    """Back-Channel Logout 1.0 2.7: end what the token names; the rows ended.

    ``sid`` present: the sessions opened by that provider session (for that
    subject, when both are given). Only ``sub``: every session of that
    person in this product.
    """
    live = ProductSession.objects.select_for_update().filter(
        ended_at__isnull=True, identity__issuer=issuer
    )
    if sid:
        EndedProviderSession.objects.get_or_create(issuer=issuer, provider_sid=sid)
        live = live.filter(provider_sid=sid)
        if subject:
            live = live.filter(identity__subject=subject)
    elif subject:
        live = live.filter(identity__subject=subject)
    else:
        return []
    return _end(list(live), reason=ProductSession.EndReason.BACKCHANNEL)


def end_by_logout_token(*, issuer: str, subject: str | None, sid: str | None) -> int:
    return len(end_for_logout_token(issuer=issuer, subject=subject, sid=sid))


def provider_session_ended(*, issuer: str, sid: str) -> bool:
    return bool(sid) and EndedProviderSession.objects.filter(
        issuer=issuer, provider_sid=sid
    ).exists()


def record_sign_in(
    *,
    identity: FederatedIdentity,
    session_key: str,
    provider_sid: str,
    organization_id,
    auth_time,
) -> ProductSession:
    return ProductSession.objects.create(
        identity=identity,
        session_key=session_key,
        provider_sid=provider_sid,
        organization_id=organization_id,
        auth_time=auth_time,
    )


def _uuid(value: Any) -> uuid.UUID | None:
    try:
        return uuid.UUID(str(value)) if value else None
    except ValueError:
        return None


def end_one(product_session_id, *, reason: str) -> None:
    pk = _uuid(product_session_id)
    if pk is None:
        return
    ProductSession.objects.filter(pk=pk, ended_at__isnull=True).update(
        ended_at=timezone.now(), end_reason=reason
    )


def follow_rotated_key(product_session_id, session_key: str) -> None:
    """Keep the row pointing at the session after the product cycled its key."""
    pk = _uuid(product_session_id)
    if pk and session_key:
        ProductSession.objects.filter(pk=pk, ended_at__isnull=True).exclude(
            session_key=session_key
        ).update(session_key=session_key)


def tracked_session_id(session: Any) -> uuid.UUID | None:
    """The ProductSession this Django session belongs to, if a sign-in opened it."""
    if session is None:
        return None
    data = session.get(SESSION_KEY)
    return _uuid(data.get("product_session_id")) if isinstance(data, dict) else None


def forget(request: Any, *, reason: str = ProductSession.EndReason.SIGNED_OUT) -> None:
    """This session is no longer the WorkEasy360 sign-in it was.

    Ends its ProductSession record and removes the connector's data from the
    session, without signing anybody out - for a product whose own sign-in
    (a password, say) replaces the WorkEasy360 one in the same session.
    """
    session = getattr(request, "session", None)
    if session is None:
        return
    end_one(tracked_session_id(session), reason=reason)
    session.pop(SESSION_KEY, None)


def on_user_logged_out(sender: Any, request: Any = None, user: Any = None, **kwargs: Any) -> None:
    """``django.contrib.auth.user_logged_out``: sent before the session is flushed."""
    session = getattr(request, "session", None) if request is not None else None
    end_one(tracked_session_id(session), reason=ProductSession.EndReason.SIGNED_OUT)
