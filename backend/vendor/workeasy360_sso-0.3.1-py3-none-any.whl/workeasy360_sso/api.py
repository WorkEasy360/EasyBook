"""The supported API for products that serve the sign-in from their own views.

The connector's own views (``workeasy360_sso.urls``) are built on these
functions. A product whose routes, error pages or session rules are its own
- an API-only backend behind a single-page frontend, say - calls them from
its views instead:

.. code-block:: python

    from workeasy360_sso import api

    def start(request):
        try:
            return api.begin_sign_in(request, next_path="/", organization=request.GET.get("organization"))
        except api.SignInRefused as refusal:
            return redirect(f"/login?sso_error={refusal.code}")

    def callback(request):
        try:
            result = api.complete_sign_in(request)
        except api.SignInRefused as refusal:
            return redirect(f"/login?sso_error={refusal.code}")
        return redirect(result.flow.next_path or "/")

Mount such views under the ``workeasy360_sso`` namespace with the connector's
route names (``callback`` above all: system check ``E005`` compares the
registered redirect URI with it), see :func:`workeasy360_sso.urls.namespaced`.
"""

from __future__ import annotations

from urllib.parse import urlencode

from django.http import HttpRequest, HttpResponse, HttpResponseRedirect
from django.utils.cache import add_never_cache_headers

from workeasy360_sso import discovery, flow, sessions
from workeasy360_sso.authentication import (
    REAUTH_CONFIRM,
    REAUTH_SIGN_IN,
    SignInResult,
    complete,
)
from workeasy360_sso.conf import SSOConfig, get_config
from workeasy360_sso.errors import STAGE_CONFIGURATION, STAGE_START, SignInRefused
from workeasy360_sso.models import ProductSession
from workeasy360_sso.organizations import SSOContext, get_context

__all__ = [
    "REAUTH_CONFIRM",
    "REAUTH_SIGN_IN",
    "SSOContext",
    "SignInRefused",
    "SignInResult",
    "begin_sign_in",
    "complete_sign_in",
    "end_session_url",
    "forget_sign_in",
    "get_context",
    "no_store",
]


def no_store(response: HttpResponse) -> HttpResponse:
    """The headers every sign-in response carries: never cached, never a referrer."""
    add_never_cache_headers(response)
    response["Cache-Control"] = "no-store"
    # The callback URL carries an authorization code: never leak it onward.
    response["Referrer-Policy"] = "no-referrer"
    return response


def begin_sign_in(
    request: HttpRequest,
    *,
    next_path: str,
    organization: str | None = None,
    prompt: str = "",
    reauth_subject: str = "",
    automatic: bool = False,
) -> HttpResponse:
    """The redirect that starts a sign-in at WorkEasy360.

    ``next_path`` is stored as given and returned on the callback as
    ``result.flow.next_path``: sanitise it first (``redirects.safe_next``
    does the connector's rules). ``organization`` is forwarded only when it
    is a UUID, and the callback then insists the token is for it.
    ``reauth_subject`` makes this "confirm it's you": the callback refuses
    any other subject (``prompt="login"`` asks for a fresh sign-in).

    Sets this browser's binding cookie when it has none; concurrent sign-ins
    in several tabs share it, each with its own single-use flow. Raises
    :class:`SignInRefused` (``unavailable``) when the connector is not
    configured or the provider's metadata cannot be read.
    """
    config = get_config()
    if not config.is_configured:
        raise SignInRefused("unavailable", log_reason="not_configured", stage=STAGE_CONFIGURATION)
    try:
        authorization = flow.begin(
            config,
            request,
            organization=organization,
            next_path=next_path,
            prompt=prompt,
            reauth_subject=reauth_subject,
            automatic=automatic,
        )
    except discovery.DiscoveryError as exc:
        raise SignInRefused(
            "unavailable", log_reason="discovery_unavailable", stage=STAGE_START
        ) from exc
    response = HttpResponseRedirect(authorization.url)
    if authorization.set_binding_cookie:
        flow.set_binding_cookie(response, request, authorization.binding)
    return no_store(response)


def complete_sign_in(
    request: HttpRequest, *, reauthentication: str = REAUTH_CONFIRM
) -> SignInResult:
    """Finish the sign-in this callback request carries, or raise :class:`SignInRefused`.

    On success the person is signed in (a new session id), the session is
    bound to the verified organization and recorded for back-channel logout.
    ``result.binding`` is what the organization adapter returned.

    ``reauthentication`` decides what a successful "confirm it's you" does:
    ``REAUTH_CONFIRM`` (default) records it and changes nothing else;
    ``REAUTH_SIGN_IN`` signs the same person in again, adapters included.
    """
    return complete(get_config(), request, reauthentication=reauthentication)


def end_session_url(config: SSOConfig | None = None) -> str:
    """Where "sign out of WorkEasy360 too" sends the browser (RP-Initiated Logout 1.0).

    ``""`` when no post-logout redirect URI is configured or the provider
    advertises no ``end_session_endpoint``. Nobody is signed out here: the
    product ends its own session first, and WorkEasy360 asks the person to
    confirm before ending its own.
    """
    config = config or get_config()
    if not config.post_logout_redirect_uri:
        return ""
    end_session = discovery.optional_endpoint(config, "end_session_endpoint")
    if not end_session:
        return ""
    query = urlencode(
        {"client_id": config.client_id, "post_logout_redirect_uri": config.post_logout_redirect_uri}
    )
    separator = "&" if "?" in end_session else "?"
    return f"{end_session}{separator}{query}"


def forget_sign_in(
    request: HttpRequest, *, reason: str = ProductSession.EndReason.REPLACED
) -> None:
    """This session stops being a WorkEasy360 sign-in (another sign-in replaced it).

    Ends its back-channel record and drops the connector's session data; the
    person stays signed in. Signing out needs nothing: every Django logout
    ends the record by itself.
    """
    sessions.forget(request, reason=reason)
