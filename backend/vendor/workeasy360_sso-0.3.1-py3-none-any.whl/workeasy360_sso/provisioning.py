"""Turning a verified WorkEasy360 identity into one of the product's users.

The rule (completion-design 3.5, and the brief's "never merge on email"):

* an identity already linked on ``(issuer, sub)`` is that user, always;
* a new identity becomes a **new** local user by default;
* linking onto an existing local account by email address is **off** unless
  the product turns it on, and even then only when WorkEasy360 says the
  address is verified, never onto an account linked to another subject, and
  the local password is retired at the link;
* an email that already belongs to an unlinked local user, with linking off,
  is ``account_conflict`` - never a silent merge.

A product with its own rules subclasses :class:`DefaultUserAdapter` and names
it in ``WORKEASY360_USER_ADAPTER``.
"""

from __future__ import annotations

import logging
from typing import Any

from django.contrib.auth import get_user_model
from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.db import IntegrityError, transaction
from django.http import HttpRequest
from django.utils import timezone
from django.utils.module_loading import import_string

from workeasy360_sso.conf import SSOConfig
from workeasy360_sso.errors import SignInRefused
from workeasy360_sso.models import FederatedIdentity

logger = logging.getLogger("workeasy360_sso")


def _field_names(model: Any) -> set[str]:
    return {field.name for field in model._meta.get_fields()}


class DefaultUserAdapter:
    """Override any method; keep the guarantees listed in the module docstring."""

    def __init__(self, config: SSOConfig) -> None:
        self.config = config

    # --- the entry point -------------------------------------------------

    def resolve(
        self, request: HttpRequest, *, claims: dict[str, Any]
    ) -> tuple[AbstractBaseUser, FederatedIdentity]:
        issuer, subject = self.config.issuer, str(claims["sub"])
        for _attempt in range(2):
            try:
                with transaction.atomic():
                    return self._resolve(request, issuer=issuer, subject=subject, claims=claims)
            except IntegrityError:
                # Two first sign-ins of the same person raced; the loser reads
                # the winner's row on the retry.
                logger.info("workeasy360_sso.identity_race", extra={"subject": subject})
        raise SignInRefused("account_conflict", log_reason="identity_race")

    def _resolve(
        self, request: HttpRequest, *, issuer: str, subject: str, claims: dict[str, Any]
    ) -> tuple[AbstractBaseUser, FederatedIdentity]:
        identity = (
            FederatedIdentity.objects.select_for_update()
            .select_related("user")
            .filter(issuer=issuer, subject=subject)
            .first()
        )
        if identity is not None:
            if identity.status != FederatedIdentity.Status.ACTIVE:
                raise SignInRefused("account_disabled", log_reason="identity_suspended")
            user = identity.user
            if not self.is_user_allowed(user):
                raise SignInRefused("account_disabled", log_reason="user_inactive")
            if self.config.sync_profile:
                self.update_user(user, claims)
            identity.last_sign_in_at = timezone.now()
            identity.save(update_fields=["last_sign_in_at"])
            return user, identity

        user = None
        linked_existing = False
        if self.config.link_by_verified_email:
            user = self.find_user_to_link(request, claims)
            linked_existing = user is not None
        if user is None:
            user = self.create_user(request, claims)
        elif not self.is_user_allowed(user):
            raise SignInRefused("account_disabled", log_reason="user_inactive")

        identity = FederatedIdentity.objects.create(
            user=user,
            issuer=issuer,
            subject=subject,
            email_at_link=str(claims.get("email") or "")[:254],
            last_sign_in_at=timezone.now(),
        )
        if linked_existing:
            self.retire_local_credentials(user)
        logger.info(
            "workeasy360_sso.identity_linked",
            extra={"subject": subject, "user_id": str(user.pk), "existing": linked_existing},
        )
        return user, identity

    # --- policy hooks -------------------------------------------------------

    def is_user_allowed(self, user: AbstractBaseUser) -> bool:
        return bool(getattr(user, "is_active", True))

    def find_user_to_link(
        self, request: HttpRequest, claims: dict[str, Any]
    ) -> AbstractBaseUser | None:
        """An existing local account to link by verified address, or None."""
        email = str(claims.get("email") or "").strip()
        if not email:
            return None
        if claims.get("email_verified") is not True:
            raise SignInRefused("email_unverified")
        UserModel = get_user_model()
        email_field = UserModel.get_email_field_name()
        candidates = list(
            UserModel._default_manager.filter(**{f"{email_field}__iexact": email})[:2]
        )
        if not candidates:
            return None
        if len(candidates) > 1:
            raise SignInRefused("account_conflict", log_reason="ambiguous_email")
        candidate = candidates[0]
        if FederatedIdentity.objects.filter(user=candidate, issuer=self.config.issuer).exists():
            # Already linked to another WorkEasy360 subject.
            raise SignInRefused("account_conflict", log_reason="linked_to_other_subject")
        return candidate

    def retire_local_credentials(self, user: AbstractBaseUser) -> None:
        """A linked account signs in through WorkEasy360 only from now on."""
        user.set_unusable_password()
        user.save(update_fields=["password"])

    def username_for(self, claims: dict[str, Any]) -> str:
        UserModel = get_user_model()
        username_field = UserModel.USERNAME_FIELD
        if username_field == UserModel.get_email_field_name():
            email = str(claims.get("email") or "").strip()
            if not email:
                raise SignInRefused("email_missing")
            return BaseUserManager.normalize_email(email)
        return f"w360-{claims['sub']}"[:150]

    def create_user(self, request: HttpRequest, claims: dict[str, Any]) -> AbstractBaseUser:
        UserModel = get_user_model()
        username_field = UserModel.USERNAME_FIELD
        username = self.username_for(claims)
        lookup = {f"{username_field}__iexact": username}
        if UserModel._default_manager.filter(**lookup).exists():
            # Never merge on an address: the person must be linked deliberately.
            raise SignInRefused("account_conflict", log_reason="username_taken")
        user = UserModel(**{username_field: username})
        self._apply_profile(user, claims)
        user.set_unusable_password()
        user.save()
        return user

    def update_user(self, user: AbstractBaseUser, claims: dict[str, Any]) -> None:
        before = {name: getattr(user, name, None) for name in ("first_name", "last_name", "email")}
        self._apply_profile(user, claims, include_email=self._email_is_not_username())
        changed = [
            name for name, value in before.items() if getattr(user, name, None) != value
        ]
        if changed:
            user.save(update_fields=changed)

    # --- helpers --------------------------------------------------------------

    def _email_is_not_username(self) -> bool:
        UserModel = get_user_model()
        return UserModel.USERNAME_FIELD != UserModel.get_email_field_name()

    def _apply_profile(
        self, user: AbstractBaseUser, claims: dict[str, Any], *, include_email: bool = True
    ) -> None:
        fields = _field_names(type(user))
        given = str(claims.get("given_name") or "").strip()
        family = str(claims.get("family_name") or "").strip()
        if not given and not family and claims.get("name"):
            given, _, family = str(claims["name"]).strip().partition(" ")
        if "first_name" in fields and given:
            user.first_name = given[:150]
        if "last_name" in fields and family:
            user.last_name = family[:150]
        email_field = type(user).get_email_field_name()
        email = str(claims.get("email") or "").strip()
        if include_email and email and email_field in fields and email_field != type(user).USERNAME_FIELD:
            setattr(user, email_field, email[:254])


def get_user_adapter(config: SSOConfig) -> DefaultUserAdapter:
    return import_string(config.user_adapter)(config)
