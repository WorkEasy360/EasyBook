"""Readiness self-test against the real WorkEasy360 provider.

Checks, in order, and stops at the first failure:

1. the configuration validates;
2. discovery answers and names exactly the configured issuer;
3. the key set has at least one usable RS256/ES256 signing key;
4. **this product's credential authenticates**: one entitlement question
   about a random organization id. ``200`` (any decision) proves the client
   id, the credential and the clock are right; ``401`` means the credential
   is wrong, expired or revoked; ``403`` means the integration is suspended.

No user, no browser and no personal data are involved. Exit status 0 means
ready; 1 means not ready, with the reason printed.
"""

from __future__ import annotations

import json
import uuid

from django.core.management.base import BaseCommand

from workeasy360_sso import client_auth, discovery, http
from workeasy360_sso.conf import SUPPORTED_ALGORITHMS, get_config


class Command(BaseCommand):
    help = "Verify this product's WorkEasy360 SSO configuration against the live provider."

    def add_arguments(self, parser):
        parser.add_argument("--json", action="store_true", help="Machine-readable output.")

    def handle(self, *args, **options):
        report = self._run()
        if options["json"]:
            self.stdout.write(json.dumps(report, indent=2))
        else:
            for step in report["steps"]:
                mark = "ok " if step["ok"] else "FAIL"
                self.stdout.write(f"[{mark}] {step['name']}: {step['detail']}")
            self.stdout.write("READY" if report["ready"] else "NOT READY")
        if not report["ready"]:
            raise SystemExit(1)

    def _run(self) -> dict:
        steps: list[dict] = []

        def step(name: str, ok: bool, detail: str) -> bool:
            steps.append({"name": name, "ok": ok, "detail": detail})
            return ok

        config = get_config()
        if not step(
            "configuration",
            config.is_configured,
            "valid" if config.is_configured else "; ".join(config.problems),
        ):
            return {"ready": False, "steps": steps}

        discovery.reset_cache()
        try:
            document = discovery.metadata(config, refresh=True)
            step("discovery", True, f"issuer {document['issuer']}")
        except discovery.DiscoveryError as exc:
            step("discovery", False, str(exc))
            return {"ready": False, "steps": steps}

        try:
            keys = discovery.jwks(config, refresh=True).get("keys", [])
        except discovery.DiscoveryError as exc:
            step("signing keys", False, str(exc))
            return {"ready": False, "steps": steps}
        usable = [k for k in keys if k.get("alg") in SUPPORTED_ALGORITHMS and k.get("kid")]
        if not step("signing keys", bool(usable), f"{len(usable)} usable key(s)"):
            return {"ready": False, "steps": steps}

        endpoint = document.get("workeasy360_entitlement_endpoint")
        if not step("entitlement endpoint", bool(endpoint), endpoint or "not advertised"):
            return {"ready": False, "steps": steps}

        fields, headers = client_auth.authentication(config)
        data = {"organization_id": str(uuid.uuid4()), "write": "false", **fields}
        try:
            response = http.post_form(config, endpoint, data, headers)
        except http.ProviderUnavailable as exc:
            step("client authentication", False, f"unreachable: {exc}")
            return {"ready": False, "steps": steps}
        status = response.status_code
        verdicts = {
            200: (True, "the credential authenticates this client"),
            401: (False, "invalid_client: wrong client id or credential, or it is revoked/expired"),
            403: (False, "the integration is suspended or not active"),
            429: (False, "rate limited; retry in a minute"),
        }
        ok, detail = verdicts.get(status, (False, f"unexpected HTTP {status}"))
        if not step("client authentication", ok, detail):
            return {"ready": False, "steps": steps}

        step(
            "back-channel logout",
            True,
            "supported by the provider"
            if document.get("backchannel_logout_supported")
            else "not advertised by the provider (sessions end at the re-check window instead)",
        )
        return {"ready": all(s["ok"] for s in steps), "steps": steps}
