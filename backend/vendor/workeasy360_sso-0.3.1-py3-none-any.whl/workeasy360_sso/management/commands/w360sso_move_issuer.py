"""Move this product's linked identities from a previous issuer to the configured one.

When WorkEasy360's central sign-in moves to a new name (``auth.workeasy360.com``
to ``accounts.workeasy360.com``, platform ADR-067), the provider, its keys and
every person's ``sub`` stay the same - only ``iss`` changes. The connector links
people on ``(issuer, sub)``, so a product that changes ``WORKEASY360_ISSUER``
without moving its links would no longer recognise anyone who signed in before:
depending on its provisioning rules it would refuse them or create a second,
empty local account.

Run this in the same release that changes ``WORKEASY360_ISSUER``, before that
release takes traffic::

    python manage.py w360sso_move_issuer --from https://auth.workeasy360.com          # dry run
    python manage.py w360sso_move_issuer --from https://auth.workeasy360.com --apply  # move

Rules:

* the destination is always the **configured** issuer - never one the product
  does not verify tokens against;
* one transaction: everything moves or nothing does;
* if anyone is already linked under both issuers (they signed in after the
  configuration changed but before this ran), nothing moves and the people
  concerned are listed: two local accounts for one person need a human
  decision, never an automatic merge;
* product sessions follow their identity; ended provider sessions move too, so
  a sign-in already in flight is still refused if its session ended;
* idempotent - running it again moves nothing.

Rollback is the same command the other way round, after the setting is put
back: ``--from https://accounts.workeasy360.com``.
"""

from __future__ import annotations

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from workeasy360_sso.conf import get_config, url_problem
from workeasy360_sso.models import EndedProviderSession, FederatedIdentity, ProductSession

#: How many conflicting subjects to print; the count is always exact.
SHOW_AT_MOST = 50


class Command(BaseCommand):
    help = "Move linked WorkEasy360 identities from a previous issuer to WORKEASY360_ISSUER."

    def add_arguments(self, parser):
        parser.add_argument(
            "--from",
            dest="previous",
            required=True,
            help="The issuer the identities were linked under, exactly as it was configured.",
        )
        parser.add_argument(
            "--apply",
            action="store_true",
            help="Make the change. Without it, only report what would change.",
        )

    def handle(self, *args, **options):
        config = get_config()
        target = config.issuer
        previous = str(options["previous"] or "").strip()
        problem = url_problem(previous, allow_insecure_http=config.allow_insecure_http)
        if problem:
            raise CommandError(f"--from {problem}.")
        if previous.endswith("/"):
            raise CommandError(
                "--from must be written exactly as configured, without a trailing '/'."
            )
        if not target:
            raise CommandError("WORKEASY360_ISSUER is not configured.")
        if previous == target:
            raise CommandError(
                f"--from is already the configured issuer ({target}); nothing to move."
            )

        with transaction.atomic():
            # Lock the rows that move (FOR UPDATE cannot carry an aggregate).
            moving_ids = list(
                FederatedIdentity.objects.select_for_update()
                .filter(issuer=previous)
                .values_list("pk", flat=True)
            )
            duplicates, conflicts = self._overlap(previous, target)
            sessions = ProductSession.objects.filter(
                identity__issuer=previous, ended_at__isnull=True
            ).count()
            ended = EndedProviderSession.objects.filter(issuer=previous).count()

            self.stdout.write(f"from: {previous}")
            self.stdout.write(f"to:   {target} (WORKEASY360_ISSUER)")
            self.stdout.write(
                f"identities={len(moving_ids)} open_product_sessions={sessions} "
                f"ended_provider_sessions={ended} duplicate_links={len(duplicates)}"
            )
            if conflicts:
                self.stdout.write(
                    f"conflicts={len(conflicts)}: one person and two local accounts, or one local "
                    "account and two people - resolve each by hand, then run this again:"
                )
                for line in conflicts[:SHOW_AT_MOST]:
                    self.stdout.write(f"  {line}")
                if len(conflicts) > SHOW_AT_MOST:
                    self.stdout.write(f"  ... and {len(conflicts) - SHOW_AT_MOST} more")
            if not options["apply"]:
                self.stdout.write("dry run: nothing changed (add --apply to move)")
                return
            if conflicts:
                raise CommandError("Nothing moved: resolve the conflicts above first.")

            # The same person already linked to the same local account under
            # the new name: keep that link, carry the old link's sessions over.
            for old_pk, kept_pk in duplicates:
                ProductSession.objects.filter(identity_id=old_pk).update(identity_id=kept_pk)
                FederatedIdentity.objects.filter(pk=old_pk).delete()
            moved = FederatedIdentity.objects.filter(issuer=previous).update(issuer=target)
            already = set(
                EndedProviderSession.objects.filter(issuer=target).values_list(
                    "provider_sid", flat=True
                )
            )
            EndedProviderSession.objects.filter(issuer=previous).exclude(
                provider_sid__in=already
            ).update(issuer=target)
            # Any left are already recorded under the new name.
            EndedProviderSession.objects.filter(issuer=previous).delete()
        self.stdout.write(
            self.style.SUCCESS(f"moved identities={moved} folded_duplicate_links={len(duplicates)}")
        )

    @staticmethod
    def _overlap(previous: str, target: str) -> tuple[list[tuple[object, object]], list[str]]:
        """Identities linked under both issuers.

        ``duplicates``: (old link, new link) of one person on one local account
        - safe to fold. ``conflicts``: one person on two local accounts, or one
        local account holding two people - never merged automatically.
        """
        old = FederatedIdentity.objects.filter(issuer=previous)
        new = FederatedIdentity.objects.filter(issuer=target)
        old_rows = {
            row["subject"]: row
            for row in old.filter(subject__in=new.values("subject")).values(
                "pk", "subject", "user_id"
            )
        }
        duplicates: list[tuple[object, object]] = []
        conflicts: list[str] = []
        folded_subjects: set[str] = set()
        for row in new.filter(subject__in=list(old_rows)).values("pk", "subject", "user_id"):
            before = old_rows[row["subject"]]
            if before["user_id"] == row["user_id"]:
                duplicates.append((before["pk"], row["pk"]))
                folded_subjects.add(row["subject"])
            else:
                conflicts.append(
                    f"sub={row['subject']} is two local accounts: "
                    f"user={before['user_id']} (old link) and user={row['user_id']} (new link)"
                )
        old_by_user = {
            row["user_id"]: row["subject"]
            for row in old.exclude(subject__in=folded_subjects).values("user_id", "subject")
        }
        for row in (
            new.filter(user_id__in=list(old_by_user))
            .exclude(subject__in=folded_subjects)
            .values("user_id", "subject")
        ):
            if old_by_user[row["user_id"]] != row["subject"]:
                conflicts.append(
                    f"user={row['user_id']} holds two people: sub={old_by_user[row['user_id']]} "
                    f"(old link) and sub={row['subject']} (new link)"
                )
        return duplicates, sorted(conflicts)
