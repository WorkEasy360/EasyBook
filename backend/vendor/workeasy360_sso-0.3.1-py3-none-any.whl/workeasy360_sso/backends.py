"""The authentication backend a WorkEasy360 sign-in is recorded under.

It never authenticates anything by itself - there is no credential a caller
could present to it. A sign-in is completed by ``authentication.complete``,
which calls ``login()`` naming this backend, and Django then uses
:meth:`get_user` to load the person on later requests. That is why it must be
listed in ``AUTHENTICATION_BACKENDS`` (system check ``workeasy360_sso.E002``).
"""

from __future__ import annotations

from typing import Any

from django.contrib.auth import get_user_model
from django.contrib.auth.backends import BaseBackend


class WorkEasy360Backend(BaseBackend):
    def authenticate(self, request: Any, **credentials: Any) -> None:
        return None

    def get_user(self, user_id: Any):
        UserModel = get_user_model()
        try:
            user = UserModel._default_manager.get(pk=user_id)
        except (UserModel.DoesNotExist, ValueError, TypeError):
            return None
        return user if getattr(user, "is_active", True) else None
