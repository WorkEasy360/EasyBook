"""The one outbound HTTP client the connector uses.

Short timeouts, no redirects followed (a token or entitlement endpoint that
redirects is misconfigured, and following it would send a client assertion
somewhere nobody registered), and an injectable transport so tests and
corporate proxies do not need to patch anything.
"""

from __future__ import annotations

from typing import Any

import httpx

from workeasy360_sso import __version__
from workeasy360_sso.conf import SSOConfig

USER_AGENT = f"workeasy360-sso/{__version__}"


class ProviderUnavailable(Exception):
    """The provider could not be reached or answered with a server error.

    Never a denial: callers keep their last known answer (contract 06 section 6).
    """


def client(config: SSOConfig, *, timeout: float | None = None) -> httpx.Client:
    seconds = timeout or config.http_timeout
    kwargs: dict[str, Any] = {
        "timeout": httpx.Timeout(seconds, connect=min(3.0, seconds)),
        "follow_redirects": False,
        "headers": {"User-Agent": USER_AGENT, "Accept": "application/json"},
    }
    if config.http_transport is not None:
        kwargs["transport"] = config.http_transport
    return httpx.Client(**kwargs)


def get_json(config: SSOConfig, url: str) -> dict[str, Any]:
    try:
        with client(config) as http:
            response = http.get(url)
    except httpx.HTTPError as exc:
        raise ProviderUnavailable(type(exc).__name__) from exc
    if response.status_code != 200:
        raise ProviderUnavailable(f"HTTP {response.status_code}")
    try:
        payload = response.json()
    except ValueError as exc:
        raise ProviderUnavailable("invalid JSON") from exc
    if not isinstance(payload, dict):
        raise ProviderUnavailable("unexpected JSON document")
    return payload


def post_form(
    config: SSOConfig,
    url: str,
    data: dict[str, str],
    headers: dict[str, str] | None = None,
    *,
    timeout: float | None = None,
) -> httpx.Response:
    try:
        with client(config, timeout=timeout) as http:
            return http.post(url, data=data, headers=headers or {})
    except httpx.HTTPError as exc:
        raise ProviderUnavailable(type(exc).__name__) from exc
