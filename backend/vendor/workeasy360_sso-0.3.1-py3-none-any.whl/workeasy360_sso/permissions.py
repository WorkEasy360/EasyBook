"""View guards for products.

The middleware already enforces entitlement on every request of a
WorkEasy360 session. These decorators add the per-view rules a product needs:

* ``sso_login_required`` - a WorkEasy360 session (not a local one);
* ``require_fresh_access`` - ask the platform *now*, with ``write=true``,
  before a privileged or irreversible operation (contract 06 section 9);
* ``require_recent_authentication`` - "confirm it's you": a ``prompt=login``
  round trip by the same subject within ``max_age`` seconds;
* ``require_aal`` - the assurance level the WorkEasy360 session reached.

Product-specific roles stay in the product: the platform deliberately issues
no roles (contract 05 section 2).
"""

from __future__ import annotations

import time
from functools import wraps
from typing import Callable
from urllib.parse import urlencode

from django.http import HttpRequest, HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import resolve_url
from django.urls import reverse

from workeasy360_sso import entitlements
from workeasy360_sso.authentication import REAUTH_SESSION_KEY
from workeasy360_sso.conf import get_config
from workeasy360_sso.organizations import get_context

View = Callable[..., HttpResponse]


def _wants_json(request: HttpRequest) -> bool:
    """Anything that is not a page navigation gets a status code, never a redirect."""
    config = get_config()
    if any(request.path_info.startswith(p) for p in config.api_path_prefixes):
        return True
    if request.headers.get("x-requested-with", "").lower() == "xmlhttprequest":
        return True
    mode = request.headers.get("sec-fetch-mode")
    if mode is not None and mode != "navigate":
        return True
    return "application/json" in request.headers.get("accept", "")


def _start_url(request: HttpRequest, **extra: str) -> str:
    params = {"next": request.get_full_path(), **extra}
    return f"{reverse('workeasy360_sso:start')}?{urlencode(params)}"


def sign_in_redirect(request: HttpRequest) -> HttpResponse:
    """Where a person without a WorkEasy360 session goes.

    Straight into the sign-in when automatic start is on - but never after a
    sign-out of this product in this browser, and never within 60 s of a
    previous automatic start (loop guard): then the product's own sign-in
    page, which offers "Continue with WorkEasy360" as a choice (guide 6b).
    """
    from workeasy360_sso.views import AUTO_START_COOKIE, SIGNED_OUT_COOKIE

    config = get_config()
    suppressed = request.COOKIES.get(SIGNED_OUT_COOKIE) or request.COOKIES.get(AUTO_START_COOKIE)
    if config.auto_start and not suppressed:
        return HttpResponseRedirect(_start_url(request, auto="1"))
    login = resolve_url(config.login_url)
    return HttpResponseRedirect(f"{login}?{urlencode({'next': request.get_full_path()})}")


def sso_login_required(view: View) -> View:
    @wraps(view)
    def wrapper(request: HttpRequest, *args, **kwargs):
        if get_context(request) is None:
            if _wants_json(request):
                return JsonResponse({"error": "workeasy360_sign_in_required"}, status=401)
            return sign_in_redirect(request)
        return view(request, *args, **kwargs)

    return wrapper


def require_fresh_access(view: View) -> View:
    @wraps(view)
    def wrapper(request: HttpRequest, *args, **kwargs):
        context = get_context(request)
        if context is None:
            return JsonResponse({"error": "workeasy360_sign_in_required"}, status=401)
        decision = entitlements.check(
            get_config(),
            organization_id=context.organization_id,
            subject=context.subject,
            fresh=True,
        )
        if not decision.allowed:
            return JsonResponse({"error": decision.code, "reason": decision.reason}, status=403)
        if not decision.write_allowed:
            return JsonResponse(
                {"error": entitlements.READ_ONLY, "reason": decision.reason}, status=403
            )
        return view(request, *args, **kwargs)

    return wrapper


def require_recent_authentication(max_age: int = 300) -> Callable[[View], View]:
    def decorator(view: View) -> View:
        @wraps(view)
        def wrapper(request: HttpRequest, *args, **kwargs):
            confirmed_at = request.session.get(REAUTH_SESSION_KEY) if hasattr(request, "session") else None
            if isinstance(confirmed_at, int) and time.time() - confirmed_at <= max_age:
                return view(request, *args, **kwargs)
            if _wants_json(request):
                return JsonResponse({"error": "workeasy360_reauthentication_required"}, status=401)
            return HttpResponseRedirect(_start_url(request, reauth="1"))

        return wrapper

    return decorator


def require_aal(level: int) -> Callable[[View], View]:
    def decorator(view: View) -> View:
        @wraps(view)
        def wrapper(request: HttpRequest, *args, **kwargs):
            context = get_context(request)
            if context is None or context.aal < level:
                return JsonResponse({"error": "workeasy360_step_up_required"}, status=403)
            return view(request, *args, **kwargs)

        return wrapper

    return decorator
