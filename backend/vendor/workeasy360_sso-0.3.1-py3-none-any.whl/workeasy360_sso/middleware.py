"""Request-time rules: automatic sign-in, the launcher, and access enforcement.

Place ``workeasy360_sso.middleware.SSOMiddleware`` **after**
``django.contrib.auth.middleware.AuthenticationMiddleware``.

* **Launcher** - a page navigation carrying ``?organization=<uuid>`` always
  starts a sign-in for that organization, even with a session (the person
  just picked it in WorkEasy360; integration guide 6a).
* **Automatic start** (``AUTO_START``, on for SSO-only products) - a page
  navigation that needs a signed-in person, from a browser with no session,
  goes straight to the start endpoint. Never on the sign-in page, never after
  a sign-out of this product in this browser (marker cookie), never within
  60 s of a previous automatic start (loop guard), and **API calls are never
  redirected** (guide 6b).
* **Access** - a WorkEasy360 session is re-checked against the entitlement
  endpoint on the platform's cadence. ``deny`` -> 403
  ``workeasy360_access_ended``; a write while read-only -> 403
  ``workeasy360_read_only``; a refused client -> 403
  ``workeasy360_access_unverified``. The session stays valid so the person
  sees one explanation and can sign out.
* **SSO-only** - an authenticated session that did not come from WorkEasy360
  is refused with ``workeasy360_sign_in_required``.

A product that gates requests itself - an API-only backend behind a
single-page frontend that starts sign-ins on its own, say - installs
:class:`SessionTrackingMiddleware` instead: it never redirects or refuses
anything and only keeps back-channel logout pointed at the session when the
product rotates its key.
"""

from __future__ import annotations

from typing import Callable
from urllib.parse import urlencode

from django.http import HttpRequest, HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render, resolve_url
from django.urls import NoReverseMatch, reverse

from workeasy360_sso import entitlements, sessions
from workeasy360_sso.conf import get_config
from workeasy360_sso.flow import parse_uuid
from workeasy360_sso.organizations import get_context
from workeasy360_sso.views import AUTO_START_COOKIE, SIGNED_OUT_COOKIE

SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})
CONNECTOR_VIEWS = (
    "start",
    "callback",
    "logout",
    "logout_workeasy360",
    "backchannel_logout",
    "status",
)
SIGN_IN_REQUIRED = "workeasy360_sign_in_required"

ACCESS_MESSAGES = {
    "not_entitled": "Your organization does not have this product.",
    "expired": "Your organization's subscription to this product has ended.",
    "suspended": "Your organization's access to this product is suspended.",
    "membership_inactive": "Your access to this organization has ended.",
    "no_seat": "You do not have a seat for this product.",
    "read_only": "This product is read-only for your organization right now.",
    "client_refused": "This product cannot confirm your access right now.",
}


class SSOMiddleware:
    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]) -> None:
        self.get_response = get_response

    # --- classification ------------------------------------------------------

    def _connector_paths(self) -> frozenset[str]:
        paths = set()
        for name in CONNECTOR_VIEWS:
            try:
                paths.add(reverse(f"workeasy360_sso:{name}"))
            except NoReverseMatch:
                continue
        return frozenset(paths)

    def _login_path(self) -> str:
        try:
            return resolve_url(get_config().login_url)
        except NoReverseMatch:
            return ""

    def _is_exempt(self, path: str) -> bool:
        config = get_config()
        if path in self._connector_paths():
            return True
        for public in config.public_paths:
            # "/x/" covers everything under it; "/" itself is the home page
            # only - as a prefix it would make the whole product public.
            if path == public or (public.endswith("/") and public != "/" and path.startswith(public)):
                return True
        return False

    def _is_api(self, path: str) -> bool:
        return any(path.startswith(prefix) for prefix in get_config().api_path_prefixes)

    def _is_navigation(self, request: HttpRequest) -> bool:
        if request.method not in ("GET", "HEAD") or self._is_api(request.path_info):
            return False
        if request.headers.get("x-requested-with", "").lower() == "xmlhttprequest":
            return False
        mode = request.headers.get("sec-fetch-mode")
        if mode is not None:
            return mode == "navigate"
        return "text/html" in request.headers.get("accept", "")

    # --- the rules --------------------------------------------------------------

    def __call__(self, request: HttpRequest) -> HttpResponse:
        config = get_config()
        request.workeasy360 = None  # type: ignore[attr-defined]
        if not config.is_configured:
            return self.get_response(request)
        path = request.path_info
        if self._is_exempt(path):
            return self.get_response(request)

        navigation = self._is_navigation(request)
        organization = parse_uuid(request.GET.get("organization"))
        if navigation and organization is not None:
            return self._start(request, organization=str(organization), automatic=False)

        context = get_context(request)
        if not request.user.is_authenticated:
            if self._should_auto_start(request, navigation):
                return self._start(request, organization=None, automatic=True)
            return self.get_response(request)

        if context is None:
            if config.sso_only:
                return self._sign_in_required(request)
            return self.get_response(request)

        if config.enforce_entitlement:
            decision = entitlements.check(
                config, organization_id=context.organization_id, subject=context.subject
            )
            if not decision.allowed:
                return self._access_refused(request, decision.code, decision.reason)
            if request.method not in SAFE_METHODS and not decision.write_allowed:
                return self._access_refused(request, entitlements.READ_ONLY, "read_only")

        request.workeasy360 = context  # type: ignore[attr-defined]
        response = self.get_response(request)
        session = getattr(request, "session", None)
        if session is not None and context.product_session_id and session.session_key:
            sessions.follow_rotated_key(context.product_session_id, session.session_key)
        return response

    def _should_auto_start(self, request: HttpRequest, navigation: bool) -> bool:
        config = get_config()
        if not (config.auto_start and navigation):
            return False
        login_path = self._login_path()
        if login_path and request.path_info == login_path:
            return False
        if request.COOKIES.get(SIGNED_OUT_COOKIE) or request.COOKIES.get(AUTO_START_COOKIE):
            return False
        return True

    def _start(self, request: HttpRequest, *, organization: str | None, automatic: bool) -> HttpResponse:
        query = request.GET.copy()
        query.pop("organization", None)
        next_path = request.path + (f"?{query.urlencode()}" if query else "")
        params = {"next": next_path}
        if organization:
            params["organization"] = organization
        if automatic:
            params["auto"] = "1"
        return HttpResponseRedirect(f"{reverse('workeasy360_sso:start')}?{urlencode(params)}")

    def _sign_in_required(self, request: HttpRequest) -> HttpResponse:
        if self._is_api(request.path_info) or not self._is_navigation(request):
            return JsonResponse({"error": SIGN_IN_REQUIRED}, status=403)
        return render(
            request,
            "workeasy360_sso/sign_in_required.html",
            {"start_url": reverse("workeasy360_sso:start")},
            status=403,
        )

    def _access_refused(self, request: HttpRequest, code: str, reason: str) -> HttpResponse:
        config = get_config()
        if self._is_api(request.path_info) or not self._is_navigation(request):
            return JsonResponse({"error": code, "reason": reason}, status=403)
        return render(
            request,
            "workeasy360_sso/access_ended.html",
            {
                "code": code,
                "reason": reason,
                "message": ACCESS_MESSAGES.get(reason, ACCESS_MESSAGES["not_entitled"]),
                "purchase_url": config.purchase_url if reason in ("not_entitled", "expired") else "",
                "logout_url": reverse("workeasy360_sso:logout"),
            },
            status=403,
        )


class SessionTrackingMiddleware:
    """Back-channel bookkeeping only: never redirects, never refuses.

    A product may rotate a signed-in session's key (an organization switch, a
    privilege change). This keeps the session's
    :class:`~workeasy360_sso.models.ProductSession` pointed at the new key, so
    a back-channel logout still finds it. It costs nothing on a request that
    does not change the key. Place it after ``SessionMiddleware``; do not
    combine it with :class:`SSOMiddleware`, which does the same and more.
    """

    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]) -> None:
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        session = getattr(request, "session", None)
        before = session.session_key if session is not None else None
        response = self.get_response(request)
        session = getattr(request, "session", None)
        after = session.session_key if session is not None else None
        if after and after != before:
            sessions.follow_rotated_key(sessions.tracked_session_id(session), after)
        return response
