"""Mount under any prefix, e.g. ``path("auth/workeasy360/", include("workeasy360_sso.urls"))``.

The registered redirect URI must point at ``callback`` exactly (system check
``workeasy360_sso.E005`` compares the two).

A product that needs its own paths - or serves ``start`` and ``callback`` from
its own views built on :mod:`workeasy360_sso.api` - lists exactly the routes
it serves under the connector's namespace with :func:`namespaced`. The
connector finds every route by name, so the checks, the manifest and the
status page all see the product's paths; a route left out is not served.

.. code-block:: python

    from workeasy360_sso import views as sso_views
    from workeasy360_sso.urls import namespaced

    urlpatterns = [
        namespaced(
            path("api/auth/callback/workeasy360", my_views.callback, name="callback"),
            path("api/auth/workeasy360/start", my_views.start, name="start"),
            path(
                "api/auth/workeasy360/backchannel-logout",
                sso_views.backchannel_logout,
                name="backchannel_logout",
            ),
        ),
        ...
    ]
"""

from django.urls import URLPattern, URLResolver, include, path

from workeasy360_sso import views

app_name = "workeasy360_sso"

#: The route names the connector looks up.
ROUTE_NAMES = ("start", "callback", "logout", "logout_workeasy360", "backchannel_logout", "status")

urlpatterns = [
    path("start/", views.start, name="start"),
    path("callback/", views.callback, name="callback"),
    path("logout/", views.logout, name="logout"),
    path("logout/workeasy360/", views.logout_workeasy360, name="logout_workeasy360"),
    path("backchannel-logout/", views.backchannel_logout, name="backchannel_logout"),
    path("status/", views.status, name="status"),
]


def namespaced(*patterns: URLPattern | URLResolver) -> URLResolver:
    """The given routes, at the paths they name, as the connector's own.

    Each pattern's ``name`` must be one of :data:`ROUTE_NAMES`.
    """
    for pattern in patterns:
        name = getattr(pattern, "name", None)
        if name not in ROUTE_NAMES:
            raise ValueError(f"{name!r} is not a workeasy360_sso route name ({', '.join(ROUTE_NAMES)}).")
    return path("", include((list(patterns), app_name), namespace=app_name))
