"""Offline verification of the provider's ID tokens and logout tokens.

ID token: the seven certification steps of integration guide section 5 plus
the ecosystem checks of completion-design section 3.4. Each step closes a
named attack, so none is optional:

1. key selected by ``kid`` from the cached key set (one refresh, then fail);
2. the algorithm taken from **the key set entry**, never from the token
   header (algorithm confusion), and only RS256/ES256;
3. ``aud`` is this product's client id (audience confusion) and, when there
   are several audiences, ``azp`` is too;
4. ``iss`` equals the configured issuer exactly (token substitution);
5. ``exp``/``nbf``/``iat`` with the configured leeway (30 s by default);
6. ``typ`` is ``id_token`` (an access token is not an identity assertion);
7. ``nonce`` equals the one this product generated, in constant time.

Logout token: OpenID Connect Back-Channel Logout 1.0 section 2.6.
"""

from __future__ import annotations

import hmac
import time
from typing import Any

import jwt

from workeasy360_sso import discovery
from workeasy360_sso.conf import SUPPORTED_ALGORITHMS, SSOConfig

ID_TOKEN_REQUIRED = ["iss", "sub", "aud", "exp", "iat", "jti", "typ"]
LOGOUT_TOKEN_REQUIRED = ["iss", "aud", "iat", "exp", "jti", "events"]
BACKCHANNEL_LOGOUT_EVENT = "http://schemas.openid.net/event/backchannel-logout"
LOGOUT_TOKEN_TYPES = frozenset({"logout+jwt", "application/logout+jwt"})

#: A logout token older than this is refused even if ``exp`` allows it: the
#: provider delivers immediately, so an old one is a replay attempt.
MAX_LOGOUT_TOKEN_AGE = 600


class TokenRejected(Exception):
    """The token cannot be trusted. ``reason`` is a fixed, loggable string."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def _verified_claims(
    config: SSOConfig, token: str, *, required: list[str]
) -> tuple[dict[str, Any], dict[str, Any]]:
    if not isinstance(token, str) or token.count(".") != 2:
        raise TokenRejected("malformed")
    try:
        header = jwt.get_unverified_header(token)
    except jwt.PyJWTError as exc:
        raise TokenRejected("malformed") from exc

    try:
        key_entry = discovery.signing_key(config, str(header.get("kid") or ""))
    except discovery.UnknownSigningKey as exc:
        raise TokenRejected("unknown_key") from exc

    algorithm = key_entry.get("alg")
    if algorithm not in SUPPORTED_ALGORITHMS:
        raise TokenRejected("unsupported_algorithm")
    try:
        key = jwt.PyJWK(key_entry, algorithm=algorithm).key
        claims = jwt.decode(
            token,
            key,
            algorithms=[algorithm],
            audience=config.client_id,
            issuer=config.issuer,
            leeway=config.leeway,
            options={"require": required, "verify_iat": True},
        )
    except jwt.ExpiredSignatureError as exc:
        raise TokenRejected("expired") from exc
    except jwt.InvalidAudienceError as exc:
        raise TokenRejected("wrong_audience") from exc
    except jwt.InvalidIssuerError as exc:
        raise TokenRejected("wrong_issuer") from exc
    except jwt.InvalidSignatureError as exc:
        raise TokenRejected("bad_signature") from exc
    except jwt.MissingRequiredClaimError as exc:
        raise TokenRejected("missing_claim") from exc
    except (jwt.PyJWTError, ValueError, TypeError) as exc:
        raise TokenRejected("invalid") from exc

    audience = claims.get("aud")
    if isinstance(audience, list) and len(audience) > 1:
        if claims.get("azp") != config.client_id:
            raise TokenRejected("wrong_audience")
    elif "azp" in claims and claims["azp"] != config.client_id:
        raise TokenRejected("wrong_audience")
    return header, claims


def verify_id_token(config: SSOConfig, id_token: str, *, nonce: str) -> dict[str, Any]:
    _, claims = _verified_claims(config, id_token, required=ID_TOKEN_REQUIRED)
    if claims.get("typ") != "id_token":
        raise TokenRejected("not_an_id_token")
    if not nonce or not hmac.compare_digest(str(claims.get("nonce") or ""), nonce):
        raise TokenRejected("nonce_mismatch")
    subject = claims.get("sub")
    if not isinstance(subject, str) or not subject or len(subject) > 255:
        raise TokenRejected("invalid_subject")
    return claims


def verify_logout_token(config: SSOConfig, logout_token: str) -> dict[str, Any]:
    header, claims = _verified_claims(config, logout_token, required=LOGOUT_TOKEN_REQUIRED)
    token_type = str(header.get("typ") or "").lower()
    if token_type not in LOGOUT_TOKEN_TYPES:
        raise TokenRejected("not_a_logout_token")
    if "typ" in claims and claims["typ"] != "logout_token":
        raise TokenRejected("not_a_logout_token")
    events = claims.get("events")
    if not isinstance(events, dict) or not isinstance(events.get(BACKCHANNEL_LOGOUT_EVENT), dict):
        raise TokenRejected("missing_logout_event")
    if "nonce" in claims:
        # Back-Channel Logout 1.0 2.4: a logout token MUST NOT contain a nonce,
        # which is what keeps an ID token from being replayed as one.
        raise TokenRejected("nonce_present")
    subject, sid = claims.get("sub"), claims.get("sid")
    if not subject and not sid:
        raise TokenRejected("no_subject_or_session")
    for value in (subject, sid):
        if value is not None and (not isinstance(value, str) or len(value) > 255):
            raise TokenRejected("invalid_subject")
    issued_at = claims.get("iat")
    if not isinstance(issued_at, (int, float)) or time.time() - issued_at > MAX_LOGOUT_TOKEN_AGE:
        raise TokenRejected("stale")
    return claims
