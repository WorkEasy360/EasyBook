"""Client authentication for the token and entitlement endpoints (contract 07).

``private_key_jwt`` (RFC 7523) is recommended: the product signs a 60-second
assertion with a key it never sends, and the platform stores only the public
half. ``client_secret_basic`` is the alternative, with both halves
form-urlencoded before Basic encoding (RFC 6749 2.3.1).
"""

from __future__ import annotations

import base64
import time
import uuid
from urllib.parse import quote

import jwt

from workeasy360_sso import discovery
from workeasy360_sso.conf import SSOConfig

ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"

#: Well inside the platform's 300-second ceiling, which is enforced.
ASSERTION_LIFETIME = 60


def build_client_assertion(config: SSOConfig, *, audience: str = "") -> str:
    now = int(time.time())
    return jwt.encode(
        {
            "iss": config.client_id,
            "sub": config.client_id,
            # The token endpoint URL, for every back-channel call: that is what
            # the platform's verifier expects (reference client, contract 07).
            "aud": audience or discovery.endpoint(config, "token_endpoint"),
            "iat": now,
            "exp": now + ASSERTION_LIFETIME,
            "jti": uuid.uuid4().hex,
        },
        config.private_key_pem,
        algorithm=config.signing_algorithm,
        headers={"kid": config.key_id},
    )


def authentication(config: SSOConfig) -> tuple[dict[str, str], dict[str, str]]:
    """``(form fields, headers)`` that authenticate this product."""
    if config.uses_private_key_jwt:
        return (
            {
                "client_assertion_type": ASSERTION_TYPE,
                "client_assertion": build_client_assertion(config),
            },
            {},
        )
    pair = f"{quote(config.client_id, safe='')}:{quote(config.client_secret, safe='')}"
    token = base64.b64encode(pair.encode("utf-8")).decode("ascii")
    return {}, {"Authorization": f"Basic {token}"}
