"""The organization a product session is bound to.

The product session is pinned to the organization the **verified ID token**
named (completion-design 3.6). Nothing the browser sends afterwards - a
query parameter, a header, a cookie, a form field - can change it; switching
organization is a new sign-in with ``organization=<uuid>``, which the
platform checks again.

A product maps the WorkEasy360 organization id to its own tenant in
:meth:`DefaultOrganizationAdapter.bind` (create the tenant on first sign-in,
add the membership, refuse if its own rules say no).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from datetime import timezone as dt_timezone
from typing import Any

from django.contrib.auth.base_user import AbstractBaseUser
from django.http import HttpRequest
from django.utils.module_loading import import_string

from workeasy360_sso.conf import SSOConfig

SESSION_KEY = "workeasy360_sso"


@dataclass(frozen=True)
class SSOContext:
    """What the verified sign-in established, read back from the session."""

    subject: str
    organization_id: uuid.UUID
    organization_name: str
    product_code: str
    aal: int
    auth_time: datetime | None
    product_session_id: uuid.UUID | None

    @classmethod
    def from_session(cls, data: dict[str, Any]) -> SSOContext | None:
        try:
            organization_id = uuid.UUID(str(data["organization_id"]))
            subject = str(data["subject"])
        except (KeyError, ValueError, TypeError):
            return None
        auth_time = data.get("auth_time")
        product_session = data.get("product_session_id")
        return cls(
            subject=subject,
            organization_id=organization_id,
            organization_name=str(data.get("organization_name") or ""),
            product_code=str(data.get("product_code") or ""),
            aal=int(data.get("aal") or 1),
            auth_time=(
                datetime.fromtimestamp(int(auth_time), tz=dt_timezone.utc)
                if isinstance(auth_time, (int, float))
                else None
            ),
            product_session_id=uuid.UUID(product_session) if product_session else None,
        )


def get_context(request: HttpRequest) -> SSOContext | None:
    """The WorkEasy360 context of this request's session, if it has one."""
    session = getattr(request, "session", None)
    if session is None or not getattr(request, "user", None) or not request.user.is_authenticated:
        return None
    data = session.get(SESSION_KEY)
    if not isinstance(data, dict):
        return None
    return SSOContext.from_session(data)


def current_organization_id(request: HttpRequest) -> uuid.UUID | None:
    context = get_context(request)
    return context.organization_id if context else None


class DefaultOrganizationAdapter:
    """Keeps the binding in the session only. Override :meth:`bind`."""

    def __init__(self, config: SSOConfig) -> None:
        self.config = config

    def bind(
        self,
        request: HttpRequest,
        *,
        user: AbstractBaseUser,
        organization_id: uuid.UUID,
        claims: dict[str, Any],
    ) -> Any:
        """Map the organization to the product's tenant, or raise SignInRefused.

        Runs in the same database transaction as the user adapter's ``resolve``:
        a refusal here leaves no account half made. Whatever it returns (the
        product's tenant or membership, say) is the sign-in result's ``binding``.
        """
        return None


def get_organization_adapter(config: SSOConfig) -> DefaultOrganizationAdapter:
    return import_string(config.organization_adapter)(config)
